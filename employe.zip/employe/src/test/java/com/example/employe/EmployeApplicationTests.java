package com.example.employe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeApplicationTests {

	@Test
	void contextLoads() {
	}

}
